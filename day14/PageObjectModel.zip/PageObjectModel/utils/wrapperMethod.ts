import {Page} from '@playwright/test'

export interface PWWrapper{

    typeAndEnter():void;

}
import { PWWrapper } from "./wrapperMethod";
import {Page} from '@playwright/test'


// export abstract class WapperImpl implements PWWrapper{

//     page:Page

//     constructor(page:Page){
//         this.page=page
//     }
      
//     async typeAndEnter(): Promise<void> {
//        await this.page.locator("").fill("")
//        await this.page.locator("").press("Enter")
//     }
    
// }